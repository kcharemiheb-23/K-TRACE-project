# Phase 10V - Experimental Validation of the RAG-LLM Workflow

## Goal
Evaluate the full Phase 10 workflow as a research system:
run_id -> retrieval -> LLM reasoning -> structured decision -> analyst report.

## Scope
- define a representative benchmark set
- run the integrated pipeline on all benchmark cases
- inspect retrieval, reasoning, and final decision quality
- score outputs using a fixed rubric
- aggregate scores
- identify workflow weaknesses
- propose research-oriented upgrades

## Evaluation criteria
- retrieval relevance
- retrieval class-specificity
- explanation correctness
- grounding in retrieved evidence
- final decision correctness
- analyst usefulness

## Output
- benchmark set
- per-case evaluation outputs
- scoring sheet
- aggregated validation results
- weakness register
- next upgrade proposal
