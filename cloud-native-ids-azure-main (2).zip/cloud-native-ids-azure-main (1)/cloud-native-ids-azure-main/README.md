# K-TRACE: Evidence-Grounded Intrusion Analysis and Controlled Response for Kubernetes Security

K-TRACE is a research prototype for evidence-grounded intrusion analysis and controlled response in cloud-native Kubernetes environments.

The project combines run-level intrusion detection, evidence retrieval, LLM-assisted incident analysis, and deterministic response policies. Its design separates generated explanations from response authorization: the LLM does not directly execute remediation actions.

## Research objectives

The project investigates four main capabilities:

1. **Intrusion detection:** classify observed runs using telemetry-derived features.
2. **Evidence retrieval:** retrieve relevant evidence for incident analysis using lexical and dense retrieval methods.
3. **Grounded analysis:** evaluate whether generated incident explanations are supported by retrieved evidence.
4. **Controlled response:** select responses through deterministic policies and prepare Kubernetes remediation artifacts.

## Experimental environment

The study uses a controlled, single-node K3s environment with a cloud-native microservice application and security and observability components.

The evaluation includes a 120-run dataset, a retrieval benchmark, a 14-case grounding evaluation, and an 11-run integrated response benchmark, as documented in the accompanying manuscript.

The response evaluation uses client-side dry-run validation. It does not establish that live autonomous remediation is safe or production-ready.

## Repository contents

- `artifacts/` — experimental artifacts and retained evaluation evidence.
- `docs/` — phase documentation, reports, and research records.
- `manifests/` — Kubernetes configuration and deployment manifests.
- `scripts/` — implementation and experimental workflow scripts.
- `README.md` — project overview and entry point.

The contents of these directories should be consulted to identify the exact inputs, scripts, and outputs associated with each published result.

## Reproducibility

The publication version should document the dependencies, configuration, inputs, execution commands, and expected outputs required for each experiment.

Reported metrics should be traced to their corresponding retained outputs. The presence of a script alone does not establish that a result can be independently reproduced.

See the project documentation for experiment-specific procedures and limitations.

## Scope and limitations

The experiments are conducted in a controlled environment. The results should not be interpreted as proof of production-scale generalization, validated human-approval enforcement, or safe live-cluster remediation.

Retrieval and grounding results are specific to their evaluated benchmarks and scoring procedures. The manuscript describes the evaluation sizes, assumptions, and limitations.

## Safety

Run experiments only in an authorized environment. Inspect Kubernetes manifests and scripts before execution. Do not expose credentials, private keys, or sensitive infrastructure data in the repository.

## Citation and availability

The version-specific release, citation metadata, and final Code Availability statement will be added after the publication artifacts have been verified.

For scientific claims, use the accompanying K-TRACE manuscript together with the corresponding implementation and experimental evidence in this repository.
