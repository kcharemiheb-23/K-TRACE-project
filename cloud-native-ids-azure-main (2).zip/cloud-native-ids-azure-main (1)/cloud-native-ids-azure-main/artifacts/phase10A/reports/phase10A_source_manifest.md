# Phase 10A Source Manifest

## Purpose
This manifest records the exact environment artifacts reused to build the Phase 10A RAG corpus.

## Inputs
- phase8_run_feature_dataset: /home/azureuser/cloud-native-ids-azure/artifacts/phase8/output/run_feature_dataset.csv | exists=True | data_rows=120
- phase8_split_test_runs: /home/azureuser/cloud-native-ids-azure/artifacts/phase8/output/split_test_runs.csv | exists=True | data_rows=24
- phase9_log: /home/azureuser/cloud-native-ids-azure/docs/phase-logs/phase9.md | exists=True
- phase9_v2_log: /home/azureuser/cloud-native-ids-azure/docs/phase-logs/phase9_v2.md | exists=True
- phase9_v2_binary_summary: /home/azureuser/cloud-native-ids-azure/artifacts/phase9_v2/output/binary_best_model_summary_v2.csv | exists=True | data_rows=1
- phase9_v2_multiclass_summary: /home/azureuser/cloud-native-ids-azure/artifacts/phase9_v2/output/multiclass_best_model_summary_v2.csv | exists=True | data_rows=1
- phase9_v2_combined_results: /home/azureuser/cloud-native-ids-azure/artifacts/phase9_v2/output/phase9_v2_combined_results.csv | exists=True | data_rows=2
- phase9_v2_seed_robustness: /home/azureuser/cloud-native-ids-azure/artifacts/phase9_v2/output/seed_robustness_results.csv | exists=True | data_rows=10
- phase9_v2_binary_report: /home/azureuser/cloud-native-ids-azure/artifacts/phase9_v2/reports/binary_best_model_test_report_v2.txt | exists=True
- phase9_v2_multiclass_report: /home/azureuser/cloud-native-ids-azure/artifacts/phase9_v2/reports/multiclass_best_model_test_report_v2.txt | exists=True
- phase9_v2_summary_report: /home/azureuser/cloud-native-ids-azure/artifacts/phase9_v2/reports/phase9_v2_summary.md | exists=True
- phase9_v2_supervisor_report: /home/azureuser/cloud-native-ids-azure/artifacts/phase9_v2/reports/phase9_supervisor_summary.md | exists=True
