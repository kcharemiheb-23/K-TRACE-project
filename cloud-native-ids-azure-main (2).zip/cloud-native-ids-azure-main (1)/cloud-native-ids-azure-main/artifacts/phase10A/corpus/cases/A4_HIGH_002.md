# Case Summary - A4_HIGH_002

## Run metadata
- run_id: A4_HIGH_002
- class_label: A4_EXPLOIT_LIKE_PAYLOADS
- binary_label: ATTACK
- scenario_family: ATTACK
- subtype: A4_EXPLOIT_LIKE_PAYLOADS
- intensity: high
- benign_type: nan

## Binary model result
- model: DecisionTree
- true_label: ATTACK
- pred_label: ATTACK

## Multiclass model result
- model: RandomForest
- true_label: A4_EXPLOIT_LIKE_PAYLOADS
- pred_label: A4_EXPLOIT_LIKE_PAYLOADS

## Top global binary features (best model)
- 0: 0.7594936708860759
- 1: 0.240506329113924
- 2: 0.0
- 3: 0.0
- 4: 0.0
- 5: 0.0
- 6: 0.0
- 7: 0.0
- 8: 0.0
- 9: 0.0

## Top global multiclass features (best model)
- 0: 0.1455013297714701
- 1: 0.1275261141217059
- 2: 0.110814913917725
- 3: 0.1105162755528466
- 4: 0.1092865936994456
- 5: 0.0998300608809473
- 6: 0.0924242175832284
- 7: 0.0883456377823089
- 8: 0.0883197945999388
- 9: 0.0098022246113121

## Notes
- This case document was generated from validated environment outputs.
- It is intended for later RAG retrieval and LLM reasoning.
