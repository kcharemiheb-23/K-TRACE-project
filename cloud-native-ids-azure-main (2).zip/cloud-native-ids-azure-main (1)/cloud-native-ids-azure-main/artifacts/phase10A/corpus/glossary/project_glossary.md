# Project Glossary

- **RAG**: Retrieval-Augmented Generation.
- **LLM**: Large Language Model.
- **Envoy**: service-mesh proxy telemetry source.
- **Falco**: runtime security telemetry source.
- **Prometheus**: metrics telemetry source.
- **Binary task**: ATTACK vs BENIGN classification.
- **Multiclass task**: BENIGN + A1 + A2 + A3 + A4 classification.
- **Case document**: one run-level knowledge document built from validated outputs.
- **Corpus**: the full document collection that will later be chunked and embedded.
- **Top-k retrieval**: selecting the k most relevant retrieved chunks.
