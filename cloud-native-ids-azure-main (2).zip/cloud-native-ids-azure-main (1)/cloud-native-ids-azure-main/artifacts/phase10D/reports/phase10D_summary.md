# Phase 10D Summary

## Goal
Integrate the validated RAG backend and best local LLM into a standardized offline IDS reasoning system.

## Produced case results
- A1_LOW_005.json
- A2_MEDIUM_004.json
- A3_LOW_004.json
- BENIGN_CONTROLLED_PEAK_004.json

## Result snapshots
### A1_LOW_005
- class_label: A1_HTTP_PORTFLOOD
- binary_pred_label: ATTACK
- multiclass_pred_label: A1_HTTP_PORTFLOOD
- llm_decision: ATTACK
- llm_model: mistral

### A2_MEDIUM_004
- class_label: A2_INVALID_REQUEST_SPRAY
- binary_pred_label: ATTACK
- multiclass_pred_label: A2_INVALID_REQUEST_SPRAY
- llm_decision: ATTACK
- llm_model: mistral

### A3_LOW_004
- class_label: A3_RUNTIME_RECON
- binary_pred_label: ATTACK
- multiclass_pred_label: A1_HTTP_PORTFLOOD
- llm_decision: ATTACK
- llm_model: mistral

### BENIGN_CONTROLLED_PEAK_004
- class_label: BENIGN
- binary_pred_label: BENIGN
- multiclass_pred_label: BENIGN
- llm_decision: BENIGN
- llm_model: mistral

