# Phase 8 QC Report

## Corpus completeness
- planned runs: 120
- manifest runs: 120
- valid official runs: 120
- invalid official runs: 0
- missing official runs: 0
- extra raw dirs: 6

## Scenario family counts
- ATTACK: 60
- BENIGN: 60

## Class counts
- A1_HTTP_PORTFLOOD: 15
- A2_INVALID_REQUEST_SPRAY: 15
- A3_RUNTIME_RECON: 15
- A4_EXPLOIT_LIKE_PAYLOADS: 15
- BENIGN: 60

## Trim policy by class
- A1_HTTP_PORTFLOOD: [('15', '15')]
- A2_INVALID_REQUEST_SPRAY: [('10', '10')]
- A3_RUNTIME_RECON: [('10', '10')]
- A4_EXPLOIT_LIKE_PAYLOADS: [('10', '15')]
- BENIGN: [('10', '10')]

## Extra raw dirs
- PILOT_A1_LOW_001
- PILOT_A2_LOW_001
- PILOT_A3_LOW_001
- PILOT_A4_LOW_001
- PILOT_BENIGN_CONTINUOUS_BROWSE_001
- PILOT_BENIGN_CONTROLLED_NORMAL_001

## Invalid official runs

## Missing official runs

