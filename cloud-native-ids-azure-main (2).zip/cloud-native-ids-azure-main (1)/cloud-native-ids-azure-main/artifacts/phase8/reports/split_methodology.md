# Split Methodology

Phase 8 splits are generated at the run level, not the raw row level.

## Rationale
Windows, logs, and structured telemetry from the same run share common conditions and should not be divided across train/validation/test.

## Rule
- grouping unit: `run_id`
- stratification target: `class_label`
- random seed: 42

## Output files
- split_train_runs.csv
- split_val_runs.csv
- split_test_runs.csv

## Scientific purpose
This reduces leakage risk and makes Phase 9 evaluation more defensible.
