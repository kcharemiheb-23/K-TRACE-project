# Phase 10R Ground-Truth Relevance Policy

## Purpose

This file defines how relevant documents are selected for retriever evaluation. Ground truth is defined independently of the retriever ranking.

## Relevance labels

| Label | Meaning |
|---:|---|
| 1 | Relevant to the expected IDS evidence need |
| 0 | Irrelevant or not included in the ground-truth relevant set |

## Relevance criteria

A chunk is relevant if it satisfies at least one of these rules:

1. It is a same-family case document for the expected family.
2. It is a benign family document for BENIGN queries.
3. It is a methodology, feature, ML result, glossary, or case chunk containing vocabulary directly associated with the expected family.

## Family-specific evidence rules

### A1

Relevant vocabulary includes:
- A1
- HTTP_PORTFLOOD
- portflood
- http flood
- flood
- request volume
- request count
- traffic pressure
- port probing
- frontend request
- high request

### A2

Relevant vocabulary includes:
- A2
- INVALID_REQUEST_SPRAY
- invalid request
- malformed
- bad path
- suspicious path
- 4xx
- TRACE
- abnormal uri
- application-layer probing

### A3

Relevant vocabulary includes:
- A3
- RUNTIME_RECON
- runtime recon
- runtime reconnaissance
- Falco
- shell
- process
- filesystem
- whoami
- uname
- cat /etc/passwd
- container activity

### A4

Relevant vocabulary includes:
- A4
- EXPLOIT_LIKE_PAYLOADS
- exploit-like
- payload
- path traversal
- injection
- encoded payload
- suspicious URL
- suspicious URI

### BENIGN

Relevant vocabulary includes:
- BENIGN
- benign
- normal
- idle
- browse
- non-attack
- baseline
- normal load
- controlled idle
- continuous browse

## Research note

This policy is intentionally explicit and reproducible. It can be manually refined later, but Phase 10R begins with a documented independent relevance policy so that Precision@k, Recall@k, and MRR are meaningful.
