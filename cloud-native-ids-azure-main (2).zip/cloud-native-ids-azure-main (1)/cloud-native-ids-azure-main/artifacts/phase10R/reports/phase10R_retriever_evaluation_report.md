# Phase 10R Retriever Evaluation Report

## 1. Purpose

Phase 10R evaluates the RAG retriever as an independent component of the cloud-native IDS reasoning pipeline. This phase was created after supervisor feedback that the retriever and RAG validation were not sufficiently visible or measurable.

## 2. Retriever approach

The current retriever is evaluated as a dense semantic vector retriever. The retrieval formulation is query embedding versus document-chunk embedding, followed by top-k vector similarity ranking. The current system is not evaluated as BM25 or exact keyword retrieval.

| Search approach | Status |
|---|---|
| Exact keyword search | Not current approach |
| BM25 sparse lexical search | Not current approach |
| Dense semantic vector search | Current approach |
| Hybrid search | Future upgrade candidate |

## 3. Ground-truth definition

Ground truth was defined independently from retrieval output. A chunk is relevant when it supports the expected IDS evidence need for the query family. Same-family case documents are considered strongly relevant, while methodology, feature, glossary, and result chunks are relevant when they contain family-specific evidence vocabulary.

## 4. SMART-style retrieval metrics

The following metrics were computed:

- **Precision@k**: proportion of top-k retrieved chunks that are relevant.
- **Recall@k**: proportion of all ground-truth relevant chunks found in top-k.
- **F1@k**: harmonic mean of Precision@k and Recall@k.
- **MRR**: mean reciprocal rank of the first relevant result.
- **Same-family ratio@k**: proportion of retrieved chunks from the expected class family.
- **Cross-class contamination@k**: proportion of retrieved chunks from a wrong attack/benign family.
- **Self-hit ratio@k**: proportion of retrieved chunks directly matching the same run ID.
- **Evidence diversity@k**: proportion of unique documents in top-k evidence.

## 5. Overall results

| Metric | Value |
|---|---:|
| Query count | 22 |
| MRR | 0.7311 |
| Precision@5 | 0.5182 |
| Recall@5 | 0.1747 |
| F1@5 | 0.2466 |
| Same-family ratio@5 | 0.4545 |
| Cross-class contamination@5 | 0.4182 |
| Self-hit ratio@5 | 0.1364 |
| Benign/attack contamination@5 | 0.0455 |
| Evidence diversity@5 | 1.0000 |

## 6. Results by group

| Group | Queries | MRR | Precision@5 | Recall@5 | Contamination@5 | Self-hit@5 |
|---|---:|---:|---:|---:|---:|---:|
| ALL | 22 | 0.7311 | 0.5182 | 0.1747 | 0.4182 | 0.1364 |
| query_type=case_id_query | 11 | 0.5833 | 0.3455 | 0.0946 | 0.6545 | 0.1091 |
| query_type=semantic_family_query | 11 | 0.8788 | 0.6909 | 0.2547 | 0.1818 | 0.1636 |
| expected_family=A1 | 4 | 0.3333 | 0.4000 | 0.2000 | 0.4000 | 0.1500 |
| expected_family=A2 | 4 | 0.5625 | 0.3500 | 0.1750 | 0.6500 | 0.1500 |
| expected_family=A3 | 4 | 0.7500 | 0.6500 | 0.2955 | 0.3500 | 0.1000 |
| expected_family=A4 | 4 | 0.8750 | 0.3000 | 0.1500 | 0.7000 | 0.1000 |
| expected_family=BENIGN | 6 | 1.0000 | 0.7667 | 0.0935 | 0.1333 | 0.1667 |

## 7. Weak queries and error analysis

The following queries were flagged because they had low Precision@5, low Recall@5, or high contamination:

| Query | Run | Type | Family | P@5 | R@5 | MRR | Contam@5 | Interpretation |
|---|---|---|---|---:|---:|---:|---:|---|
| Q001 | A1_LOW_005 | case_id_query | A1 | 0.2000 | 0.1000 | 0.3333 | 0.8000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q003 | A1_MEDIUM_004 | case_id_query | A1 | 0.2000 | 0.1000 | 0.3333 | 0.8000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q005 | A2_HIGH_002 | case_id_query | A2 | 0.2000 | 0.1000 | 0.2500 | 0.8000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q007 | A2_MEDIUM_003 | case_id_query | A2 | 0.0000 | 0.0000 | 0.0000 | 1.0000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q009 | A3_LOW_002 | case_id_query | A3 | 0.2000 | 0.0909 | 0.5000 | 0.8000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q011 | A3_MEDIUM_004 | case_id_query | A3 | 0.4000 | 0.1818 | 0.5000 | 0.6000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q013 | A4_LOW_005 | case_id_query | A4 | 0.2000 | 0.1000 | 1.0000 | 0.8000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q014 | A4_LOW_005 | semantic_family_query | A4 | 0.4000 | 0.2000 | 1.0000 | 0.6000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q015 | A4_MEDIUM_003 | case_id_query | A4 | 0.2000 | 0.1000 | 0.5000 | 0.8000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q016 | A4_MEDIUM_003 | semantic_family_query | A4 | 0.4000 | 0.2000 | 1.0000 | 0.6000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q017 | BENIGN_CONTINUOUS_BROWSE_001 | case_id_query | BENIGN | 0.6000 | 0.0732 | 1.0000 | 0.4000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q018 | BENIGN_CONTINUOUS_BROWSE_001 | semantic_family_query | BENIGN | 0.8000 | 0.0976 | 1.0000 | 0.0000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q019 | BENIGN_CONTINUOUS_BROWSE_006 | case_id_query | BENIGN | 0.6000 | 0.0732 | 1.0000 | 0.4000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q020 | BENIGN_CONTINUOUS_BROWSE_006 | semantic_family_query | BENIGN | 0.8000 | 0.0976 | 1.0000 | 0.0000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q021 | BENIGN_CONTROLLED_IDLE_002 | case_id_query | BENIGN | 1.0000 | 0.1220 | 1.0000 | 0.0000 | Retriever may be returning weak or class-contaminated evidence for this query. |
| Q022 | BENIGN_CONTROLLED_IDLE_002 | semantic_family_query | BENIGN | 0.8000 | 0.0976 | 1.0000 | 0.0000 | Retriever may be returning weak or class-contaminated evidence for this query. |

## 8. Interpretation

This phase makes the retriever visible and measurable. High Precision@k means the retriever gives mostly useful evidence. High Recall@k means the retriever finds a large portion of the known relevant evidence. High MRR means relevant evidence appears early in the ranking. High cross-class contamination means retrieved evidence may mislead the LLM by mixing attack families.

## 9. Research conclusion

Phase 10R provides the missing RAG validation layer requested by the supervisor. It separates retriever behavior from LLM reasoning and shows whether the RAG system is grounded in relevant evidence. The results should be used to justify Phase 10U, especially if contamination is high, recall is low, or the retriever depends too strongly on self-hit case documents.

## 10. Dashboard integration

The retriever evaluation is exported to dashboard-ready CSV files and displayed through a Streamlit dashboard page under `scripts/phase10E/pages/10_Retriever_Evaluation.py`.
