# Recovered Chunk Manifest from Chroma

- vectorstore: /home/azureuser/cloud-native-ids-azure/artifacts/phase10B/vectorstore
- collection: ids_rag_corpus
- recovered_rows: 62
- output: /home/azureuser/cloud-native-ids-azure/artifacts/phase10B/chunks/chunk_records.jsonl

## Expected from Phase 10B report

- expected_total_chunks: 62

## Interpretation

Recovered chunk count matches the Phase 10B chunk report.
