# Phase 10R Retriever Approach

## Current retriever type

The current implemented retriever is a **dense semantic vector retriever**.

It is not an exact keyword search engine and it is not a BM25 lexical retriever unless a separate BM25 component is later added.

## Retrieval formulation

The retrieval process is formulated as:

```text
query text
→ embedding(query)
→ vector similarity search against embedded corpus chunks
→ ranked top-k chunks
→ retrieved evidence passed to the LLM reasoning layer
```

More formally:

```text
q = embedding(query)
d_i = embedding(document_chunk_i)
score(q, d_i) = vector similarity(q, d_i)
top-k = highest scoring chunks
```

## Search classification

| Search approach | Used in current system? | Explanation |
|---|---:|---|
| Exact keyword search | No | The current retriever does not only match identical terms. |
| BM25 sparse lexical search | No | BM25 is not currently the implemented retrieval formulation. |
| Dense semantic search | Yes | Query and chunks are encoded into vectors and compared semantically. |
| Hybrid lexical + semantic search | Not yet | This can be proposed later as a Phase 10U upgrade. |

## Embedding and vector storage

- Embedding model used in the project design: `all-MiniLM-L6-v2`
- Vector database used in the project design: `Chroma`
- Chunk file inspected: `artifacts/phase10B/chunks/chunk_records.jsonl`
- Vector store inspected: `artifacts/phase10B/vectorstore`

## Relationship between the researcher and the embedding

The researcher defines the corpus, chunking policy, query formulation, relevance criteria, and evaluation metrics. The embedding model transforms query text and document chunks into a vector space. The retriever then ranks chunks according to vector similarity. Therefore, the embedding model is not the research contribution by itself; the contribution is the controlled design, evaluation, and interpretation of retrieval behavior in the IDS reasoning pipeline.

## Corpus/chunk inspection

- chunk_count: 62
- section_counts:
  - cases: 48
  - features: 1
  - glossary: 1
  - methodology: 6
  - ml_results: 6

## Example chunks

- chunk_id=phase9_chunk1 | doc=phase9.md | section=methodology
- chunk_id=phase9_supervisor_summary_chunk1 | doc=phase9_supervisor_summary.md | section=methodology
- chunk_id=phase9_supervisor_summary_chunk2 | doc=phase9_supervisor_summary.md | section=methodology
- chunk_id=phase9_v2_chunk1 | doc=phase9_v2.md | section=methodology
- chunk_id=phase9_v2_summary_chunk1 | doc=phase9_v2_summary.md | section=methodology

## Vector store files observed

- artifacts/phase10B/vectorstore/chroma.sqlite3
- artifacts/phase10B/vectorstore/779faa31-831c-4386-8be4-c03ff758854b/data_level0.bin
- artifacts/phase10B/vectorstore/779faa31-831c-4386-8be4-c03ff758854b/length.bin
- artifacts/phase10B/vectorstore/779faa31-831c-4386-8be4-c03ff758854b/header.bin
- artifacts/phase10B/vectorstore/779faa31-831c-4386-8be4-c03ff758854b/link_lists.bin

## Known limitation

Dense semantic retrieval can retrieve conceptually similar but class-wrong evidence. This is why Phase 10R evaluates class-family contamination, same-family retrieval ratio, rank quality, and Recall@k.
