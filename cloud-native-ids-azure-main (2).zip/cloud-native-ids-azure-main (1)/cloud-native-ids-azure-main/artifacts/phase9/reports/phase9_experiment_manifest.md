# Phase 9 Experiment Manifest

## Dataset files
- binary: /home/azureuser/cloud-native-ids-azure/artifacts/phase8/output/feature_dataset_binary.csv
- multiclass: /home/azureuser/cloud-native-ids-azure/artifacts/phase8/output/feature_dataset_multiclass.csv
- train: /home/azureuser/cloud-native-ids-azure/artifacts/phase8/output/split_train_runs.csv
- val: /home/azureuser/cloud-native-ids-azure/artifacts/phase8/output/split_val_runs.csv
- test: /home/azureuser/cloud-native-ids-azure/artifacts/phase8/output/split_test_runs.csv

## Counts
- binary rows: 120
- multiclass rows: 120
- train rows: 72
- val rows: 24
- test rows: 24
- binary feature columns: 33
- multiclass feature columns: 33

## Class distributions
- binary: Counter({'ATTACK': 60, 'BENIGN': 60})
- multiclass: Counter({'BENIGN': 60, 'A1_HTTP_PORTFLOOD': 15, 'A3_RUNTIME_RECON': 15, 'A4_EXPLOIT_LIKE_PAYLOADS': 15, 'A2_INVALID_REQUEST_SPRAY': 15})
- train: Counter({'BENIGN': 36, 'A1_HTTP_PORTFLOOD': 9, 'A3_RUNTIME_RECON': 9, 'A4_EXPLOIT_LIKE_PAYLOADS': 9, 'A2_INVALID_REQUEST_SPRAY': 9})
- val: Counter({'BENIGN': 12, 'A1_HTTP_PORTFLOOD': 3, 'A3_RUNTIME_RECON': 3, 'A4_EXPLOIT_LIKE_PAYLOADS': 3, 'A2_INVALID_REQUEST_SPRAY': 3})
- test: Counter({'BENIGN': 12, 'A1_HTTP_PORTFLOOD': 3, 'A3_RUNTIME_RECON': 3, 'A4_EXPLOIT_LIKE_PAYLOADS': 3, 'A2_INVALID_REQUEST_SPRAY': 3})

## Seed
- random_state: 42
