# Phase 9 Summary

## Binary task
- task: binary
- best_model: DecisionTree
- test_accuracy: 0.9583333333333334
- test_precision_macro: 0.9615384615384616
- test_recall_macro: 0.9583333333333331
- test_f1_macro: 0.9582608695652174
- test_precision_binary: 0.9230769230769232
- test_recall_binary: 1.0
- test_f1_binary: 0.96
- test_roc_auc: 0.9930555555555556
- test_pr_auc: 0.9871794871794872

## Multiclass task
- task: multiclass
- best_model: RandomForest
- test_accuracy: 0.9583333333333334
- test_precision_macro: 0.95
- test_recall_macro: 0.9333333333333332
- test_f1_macro: 0.9314285714285716

## Interpretation note
- Results must be interpreted using the leakage-safe run-based split policy from Phase 8.
- Binary and multiclass results should be discussed separately.
- Feature importance plots should be used to explain source contribution.
