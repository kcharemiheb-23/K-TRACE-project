# Phase 10C Final Report

## Goal
Evaluate multiple local LLMs on the same RAG-backed IDS reasoning tasks.

## Compared models
- mistral
- phi3:mini

## Evaluation questions
- Q1 | classification_explanation | Why would a case be considered A3 runtime recon rather than A1 flooding?
- Q2 | attack_evidence | Which evidence should an analyst use to justify that a suspicious run is an attack?
- Q3 | feature_interpretation | Which features indicate abnormal behavior in suspicious cases?
- Q4 | class_comparison | Compare A1 HTTP port flood and A2 invalid request spray in terms of expected behavior.
- Q5 | analyst_decision | What should an analyst do after the system classifies a suspicious run as an attack?
- Q6 | rag_grounding | Which sources are most useful for explaining why a run was classified as A3?

## Aggregate score summary
```text
    model  correctness_0_2  grounding_0_2  consistency_0_2  no_hallucination_0_2  analyst_usefulness_0_2  overall_mean
  mistral         1.500000       1.833333         1.833333              1.666667                1.666667      1.700000
phi3:mini         1.166667       1.500000         1.166667              1.166667                1.333333      1.266667
```

## Best model
- mistral

## Interpretation notes
- The best model is the one with the strongest average balance across correctness, grounding, consistency, hallucination resistance, and analyst usefulness.
- Results remain specific to the current corpus, prompt design, and local runtime environment.
- This phase evaluates reasoning quality, not raw intrusion detection accuracy.
