# Phase 10C Run Report

- total_models: 2
- total_questions: 6
- total_outputs: 12

- mistral_Q1.json
- mistral_Q2.json
- mistral_Q3.json
- mistral_Q4.json
- mistral_Q5.json
- mistral_Q6.json
- phi3_mini_Q1.json
- phi3_mini_Q2.json
- phi3_mini_Q3.json
- phi3_mini_Q4.json
- phi3_mini_Q5.json
- phi3_mini_Q6.json
