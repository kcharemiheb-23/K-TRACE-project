# Phase 10C Score Summary

## Mean scores by model

```text
    model  correctness_0_2  grounding_0_2  consistency_0_2  no_hallucination_0_2  analyst_usefulness_0_2  overall_mean
  mistral         1.500000       1.833333         1.833333              1.666667                1.666667      1.700000
phi3:mini         1.166667       1.500000         1.166667              1.166667                1.333333      1.266667
```
