# Phase 10U Part C - Retriever Walkthrough

This walkthrough runs three representative queries against all four upgraded retrieval modes. Each row shows the top five retrieved chunks for one mode, with the family flag color: a star marks chunks of the expected family, a dash marks all others.

## A1 semantic family query

**Query:** Retrieve evidence for HTTP request flooding, elevated frontend request volume, port probing behavior, high request counts, and service traffic pressure in the cloud-native IDS.
**Expected family:** `A1`

### Mode: `dense_only`

| rank | chunk_id | family | match | score |
|---:|---|---|---|---:|
| 1 | `A1_MEDIUM_005_chunk1` | A1 | * | 0.7000 |
| 2 | `A1_MEDIUM_004_chunk1` | A1 | * | 0.6979 |
| 3 | `A1_LOW_005_chunk1` | A1 | * | 0.6783 |
| 4 | `A4_MEDIUM_003_chunk1` | A4 | - | 0.6670 |
| 5 | `BENIGN_CONTROLLED_PEAK_006_chunk1` | BENIGN | - | 0.6659 |

### Mode: `bm25_only`

| rank | chunk_id | family | match | score |
|---:|---|---|---|---:|
| 1 | `project_glossary_chunk3` | UNKNOWN | - | 31.6409 |
| 2 | `A1_MEDIUM_004_chunk1` | A1 | * | 30.9679 |
| 3 | `A1_MEDIUM_005_chunk1` | A1 | * | 30.9679 |
| 4 | `A1_LOW_005_chunk1` | A1 | * | 30.8663 |
| 5 | `A2_HIGH_002_chunk1` | A2 | - | 17.4902 |

### Mode: `rrf`

| rank | chunk_id | family | match | score |
|---:|---|---|---|---:|
| 1 | `A1_MEDIUM_005_chunk1` | A1 | * | 0.0323 |
| 2 | `A1_MEDIUM_004_chunk1` | A1 | * | 0.0323 |
| 3 | `A1_LOW_005_chunk1` | A1 | * | 0.0315 |
| 4 | `A4_HIGH_002_chunk1` | A4 | - | 0.0294 |
| 5 | `A2_HIGH_002_chunk1` | A2 | - | 0.0291 |

### Mode: `rrf_plus_metadata_rerank`

| rank | chunk_id | family | match | score |
|---:|---|---|---|---:|
| 1 | `A1_MEDIUM_005_chunk1` | A1 | * | 0.0347 |
| 2 | `A1_MEDIUM_004_chunk1` | A1 | * | 0.0347 |
| 3 | `A1_LOW_005_chunk1` | A1 | * | 0.0340 |
| 4 | `A4_HIGH_002_chunk1` | A4 | - | 0.0294 |
| 5 | `A2_HIGH_002_chunk1` | A2 | - | 0.0291 |

---

## A3 case-id query (the hardest baseline case)

**Query:** Retrieve evidence explaining IDS case A3_LOW_002 and its security-relevant telemetry behavior.
**Expected family:** `A3`

### Mode: `dense_only`

| rank | chunk_id | family | match | score |
|---:|---|---|---|---:|
| 1 | `A4_LOW_005_chunk1` | A4 | - | 0.6477 |
| 2 | `A3_LOW_002_chunk1` | A3 | * | 0.6451 |
| 3 | `A3_LOW_004_chunk1` | A3 | * | 0.6435 |
| 4 | `A1_LOW_005_chunk1` | A1 | - | 0.6385 |
| 5 | `project_glossary_chunk2` | UNKNOWN | - | 0.6349 |

### Mode: `bm25_only`

| rank | chunk_id | family | match | score |
|---:|---|---|---|---:|
| 1 | `A3_LOW_002_chunk1` | A3 | * | 14.9901 |
| 2 | `A3_LOW_004_chunk1` | A3 | * | 11.7065 |
| 3 | `project_glossary_chunk2` | UNKNOWN | - | 9.6154 |
| 4 | `A1_LOW_005_chunk1` | A1 | - | 8.7358 |
| 5 | `A4_LOW_005_chunk1` | A4 | - | 8.6121 |

### Mode: `rrf`

| rank | chunk_id | family | match | score |
|---:|---|---|---|---:|
| 1 | `A3_LOW_002_chunk1` | A3 | * | 0.0325 |
| 2 | `A3_LOW_004_chunk1` | A3 | * | 0.0320 |
| 3 | `A4_LOW_005_chunk1` | A4 | - | 0.0318 |
| 4 | `project_glossary_chunk2` | UNKNOWN | - | 0.0313 |
| 5 | `A1_LOW_005_chunk1` | A1 | - | 0.0312 |

### Mode: `rrf_plus_metadata_rerank`

| rank | chunk_id | family | match | score |
|---:|---|---|---|---:|
| 1 | `A3_LOW_002_chunk1` | A3 | * | 0.0350 |
| 2 | `A3_LOW_004_chunk1` | A3 | * | 0.0345 |
| 3 | `A4_LOW_005_chunk1` | A4 | - | 0.0318 |
| 4 | `A3_MEDIUM_004_chunk1` | A3 | * | 0.0317 |
| 5 | `project_glossary_chunk2` | UNKNOWN | - | 0.0313 |

---

## BENIGN semantic family query

**Query:** Retrieve evidence for benign cloud-native microservice behavior, normal browsing, controlled idle windows, normal load, expected service traffic, and non-attack activity.
**Expected family:** `BENIGN`

### Mode: `dense_only`

| rank | chunk_id | family | match | score |
|---:|---|---|---|---:|
| 1 | `BENIGN_CONTINUOUS_BROWSE_006_chunk1` | BENIGN | * | 0.7105 |
| 2 | `BENIGN_CONTROLLED_PEAK_004_chunk1` | BENIGN | * | 0.7103 |
| 3 | `BENIGN_CONTROLLED_PEAK_006_chunk1` | BENIGN | * | 0.7091 |
| 4 | `BENIGN_CONTROLLED_PEAK_008_chunk1` | BENIGN | * | 0.7073 |
| 5 | `BENIGN_CONTINUOUS_BROWSE_010_chunk1` | BENIGN | * | 0.7064 |

### Mode: `bm25_only`

| rank | chunk_id | family | match | score |
|---:|---|---|---|---:|
| 1 | `BENIGN_CONTROLLED_IDLE_002_chunk1` | BENIGN | * | 15.6023 |
| 2 | `BENIGN_CONTROLLED_IDLE_009_chunk1` | BENIGN | * | 15.6023 |
| 3 | `BENIGN_CONTROLLED_NORMAL_004_chunk1` | BENIGN | * | 15.5091 |
| 4 | `BENIGN_CONTINUOUS_NORMAL_005_chunk1` | BENIGN | * | 15.3105 |
| 5 | `BENIGN_CONTINUOUS_NORMAL_006_chunk1` | BENIGN | * | 15.3105 |

### Mode: `rrf`

| rank | chunk_id | family | match | score |
|---:|---|---|---|---:|
| 1 | `BENIGN_CONTROLLED_IDLE_002_chunk1` | BENIGN | * | 0.0313 |
| 2 | `BENIGN_CONTROLLED_IDLE_009_chunk1` | BENIGN | * | 0.0313 |
| 3 | `BENIGN_CONTROLLED_PEAK_004_chunk1` | BENIGN | * | 0.0311 |
| 4 | `BENIGN_CONTROLLED_PEAK_006_chunk1` | BENIGN | * | 0.0306 |
| 5 | `BENIGN_CONTINUOUS_BROWSE_006_chunk1` | BENIGN | * | 0.0305 |

### Mode: `rrf_plus_metadata_rerank`

| rank | chunk_id | family | match | score |
|---:|---|---|---|---:|
| 1 | `BENIGN_CONTROLLED_IDLE_002_chunk1` | BENIGN | * | 0.0338 |
| 2 | `BENIGN_CONTROLLED_IDLE_009_chunk1` | BENIGN | * | 0.0337 |
| 3 | `BENIGN_CONTROLLED_PEAK_004_chunk1` | BENIGN | * | 0.0335 |
| 4 | `BENIGN_CONTROLLED_PEAK_006_chunk1` | BENIGN | * | 0.0330 |
| 5 | `BENIGN_CONTINUOUS_BROWSE_006_chunk1` | BENIGN | * | 0.0329 |

---
