# Phase 10B Chunk Report

- total_documents: 34
- total_chunks: 62
- max_chars: 900
- overlap: 120

## chunks_by_section
- cases: 48
- features: 1
- glossary: 1
- methodology: 6
- ml_results: 6
