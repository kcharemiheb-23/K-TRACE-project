# Phase 10B Ingest Report

- embedding_model: all-MiniLM-L6-v2
- collection_name: ids_rag_corpus
- total_chunks: 62
- vectorstore_path: /home/azureuser/cloud-native-ids-azure/artifacts/phase10B/vectorstore
