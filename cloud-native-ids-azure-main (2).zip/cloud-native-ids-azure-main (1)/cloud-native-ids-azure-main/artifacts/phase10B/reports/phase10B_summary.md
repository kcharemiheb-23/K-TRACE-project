# Phase 10B Summary

## Goal
Build the first working RAG prototype over the validated Phase 10A corpus.

## Saved query artifacts
- query_a3_reason.json
- query_feature_abnormality.json
- reason_a3_vs_a1.json
- reason_attack_evidence.json

## query_a3_reason.json
- question: None
- model: n/a
- top_k: n/a
- sources:

## query_feature_abnormality.json
- question: None
- model: n/a
- top_k: n/a
- sources:

## reason_a3_vs_a1.json
- question: Why would a case be considered A3 runtime recon rather than A1 flooding?
- model: mistral
- top_k: 4
- sources:
  - A3_LOW_002.md | cases | A3_LOW_002_chunk1
  - A3_MEDIUM_004.md | cases | A3_MEDIUM_004_chunk1
  - A3_LOW_004.md | cases | A3_LOW_004_chunk1
  - phase9_v2_summary.md | methodology | phase9_v2_summary_chunk2

## reason_attack_evidence.json
- question: Which evidence should an analyst use to justify that a suspicious run is an attack?
- model: mistral
- top_k: 4
- sources:
  - phase9_supervisor_summary.md | methodology | phase9_supervisor_summary_chunk2
  - phase9.md | methodology | phase9_chunk1
  - phase9_supervisor_summary.md | methodology | phase9_supervisor_summary_chunk1
  - A1_LOW_005.md | cases | A1_LOW_005_chunk1

