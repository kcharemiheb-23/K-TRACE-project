# Phase 10B Source Manifest

## methodology
- count: 4
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/methodology/phase9.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/methodology/phase9_supervisor_summary.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/methodology/phase9_v2.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/methodology/phase9_v2_summary.md

## features
- count: 1
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/features/feature_dictionary.md

## ml_results
- count: 4
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/ml_results/binary_best_model.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/ml_results/combined_results.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/ml_results/multiclass_best_model.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/ml_results/robustness.md

## cases
- count: 24
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/A1_LOW_005.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/A1_MEDIUM_004.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/A1_MEDIUM_005.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/A2_HIGH_002.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/A2_MEDIUM_003.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/A2_MEDIUM_004.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/A3_LOW_002.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/A3_LOW_004.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/A3_MEDIUM_004.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/A4_HIGH_002.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/A4_LOW_005.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/A4_MEDIUM_003.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/BENIGN_CONTINUOUS_BROWSE_001.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/BENIGN_CONTINUOUS_BROWSE_006.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/BENIGN_CONTINUOUS_BROWSE_010.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/BENIGN_CONTINUOUS_NORMAL_005.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/BENIGN_CONTINUOUS_NORMAL_006.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/BENIGN_CONTINUOUS_NORMAL_008.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/BENIGN_CONTROLLED_IDLE_002.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/BENIGN_CONTROLLED_IDLE_009.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/BENIGN_CONTROLLED_NORMAL_004.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/BENIGN_CONTROLLED_PEAK_004.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/BENIGN_CONTROLLED_PEAK_006.md
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/cases/BENIGN_CONTROLLED_PEAK_008.md

## glossary
- count: 1
- /home/azureuser/cloud-native-ids-azure/artifacts/phase10A/corpus/glossary/project_glossary.md

## total_documents
- 34
