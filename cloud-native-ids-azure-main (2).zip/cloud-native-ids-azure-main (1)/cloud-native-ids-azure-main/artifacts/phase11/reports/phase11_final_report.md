# Phase 11 — Integrated IDS Response System and Unified Dashboard

## 1. Purpose
Phase 11 delivers the engineering integration layer that turns the validated
Phase 10 research pipeline into a single orchestrated offline IDS response
workflow. One command processes a run; one shell script processes the
benchmark batch; one dashboard page exposes every incident lifecycle.

## 2. Architecture
- ML attack gate (Phase 9 v2 binary + multiclass) decides BENIGN vs ATTACK.
- BENIGN runs are logged in skipped_benign_*.csv and skipped (no RAG, no LLM,
  no remediation).
- ATTACK runs invoke the upgraded Phase 10U retriever
  (rrf_plus_metadata_rerank, top_k=5).
- The local Mistral LLM (via Ollama) produces explanation, impact, and
  recommendation text. It does not classify and does not choose actions.
- A deterministic YAML policy engine maps (family, intensity) -> (severity,
  action). The policy file is Git-tracked.
- The executor renders a Kubernetes NetworkPolicy manifest (Jinja2 template)
  and runs `kubectl apply --dry-run=client` by default. Apply mode is gated
  by an allowlist of namespaces and pod prefixes.

## 3. Outputs (after demo_run.sh)
- artifacts/phase11/incidents/INC_*.json (one per attack)
- artifacts/phase11/reports/INC_*.md
- artifacts/phase11/actions/INC_*.yaml + INC_*.rollback.sh
- artifacts/phase11/logs/skipped_benign_*.csv
- artifacts/phase11/logs/orchestrator_run_*.log
- artifacts/phase11/summary/phase11_run_summary.csv

## 4. Reproducibility
The whole demo is a single command:
    bash scripts/phase11/demo_run.sh dry_run
Re-running produces the same incident set. Per-incident replay is documented
inside the dashboard.

## 5. Limitations
- Offline / batch design: the orchestrator processes saved telemetry runs.
- Single VM, single K3s cluster. NetworkPolicy actions are validated against
  this lab only.
- Three severity levels and four action types is intentional simplicity, not
  state-of-the-art SOC engineering.
- ML errors propagate. On the 11-run benchmark the multiclass model is 11/11
  correct, so apply-time errors caused by misclassification are not observed.
- The LLM produces text only. Hallucinated text is mitigated by surfacing the
  retrieved chunks alongside the LLM output and by separating action selection
  from LLM output entirely.
- Apply mode is constrained to a small allowlist; we do not claim that the
  apply path is production-safe outside this lab.

## 6. Dashboard
Page 08 of the Phase 10E v2 dashboard exposes every lifecycle event:
ML decision, retrieved evidence, LLM analyst reasoning, deterministic
policy decision, rendered manifest, rollback path, and benign-skip log.

## 7. Engineering contribution (one paragraph)
Phase 11 closes the loop. The validated ML classifier deterministically
gates LLM invocation. The validated retriever supplies evidence. The local
LLM produces analyst-readable text without selecting actions. A deterministic
policy chooses severity and action. A constrained executor renders Kubernetes
remediation manifests with rollback scripts and a default dry-run mode. A
single dashboard page tells the whole story. The pipeline that was a sequence
of phase scripts is now one orchestrated, reproducible IDS response workflow.
